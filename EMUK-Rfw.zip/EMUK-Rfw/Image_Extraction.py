import base64
from robot.api import logger

def image_extraction(h_api, response_body):
    # Check if the response body is a list
    if isinstance(response_body, list):
        saved_files = []  # To keep track of saved files
        for api_data in response_body:
            # Extract proof image and API name
            proof_img = api_data.get("proof_img")
            api_name = api_data.get("api")
            if proof_img and api_name:
                try:
                    # Decode the base64 image
                    img_data = base64.b64decode(proof_img)
                    filename = f"{h_api}_{api_name}.jpg"
                    
                    # Save the image
                    with open(filename, 'wb') as f:
                        f.write(img_data)
                    
                    # Log the image as an HTML element
                    logger.info(f"<img src='{filename}' />", html=True)
                    saved_files.append(filename)
                except Exception as e:
                    logger.error(f"Failed to process the image for API '{api_name}': {e}")

        return saved_files if saved_files else None  # Return saved files or None if no images were saved
    else:
        logger.error("Response body is not a list.")
        return None

def Response_String(response_Body):
    if isinstance(response_Body, list):
        response_strings = []  # To collect all response strings
        for api_data in response_Body:
            # Assuming each item in the list has a dictionary structure
            response_string = api_data.get("response_data")
            if response_string is not None:
                response_strings.append(response_string)
        
        if response_strings:
            return response_strings  # Return all collected response strings

    return None  # Return None if no valid response strings were found
